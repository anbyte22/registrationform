@extends('frontend.master')
@section('body')
    <div class="form-home">
        <div class="container">
            <div class="row">
                <div class="box-shadow successfont">
                    <h3>Thank you for registering to visit AAHAR 2021. Your Unique Registration number is
                        ({{ $regisid }} ). You will
                        receive your e-badge and other details on your registered email.</h3>
                </div>

            </div>
        </div>
    </div>
@endsection
